<?php

namespace App\Http\Controllers;

use App\gig_basic;
use Illuminate\Http\Request;

class GigBasicController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\gig_basic  $gig_basic
     * @return \Illuminate\Http\Response
     */
    public function show(gig_basic $gig_basic)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\gig_basic  $gig_basic
     * @return \Illuminate\Http\Response
     */
    public function edit(gig_basic $gig_basic)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\gig_basic  $gig_basic
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, gig_basic $gig_basic)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\gig_basic  $gig_basic
     * @return \Illuminate\Http\Response
     */
    public function destroy(gig_basic $gig_basic)
    {
        //
    }
}

<?php

namespace App\Http\Controllers;

use App\gig_requirement;
use Illuminate\Http\Request;

class GigRequirementController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\gig_requirement  $gig_requirement
     * @return \Illuminate\Http\Response
     */
    public function show(gig_requirement $gig_requirement)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\gig_requirement  $gig_requirement
     * @return \Illuminate\Http\Response
     */
    public function edit(gig_requirement $gig_requirement)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\gig_requirement  $gig_requirement
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, gig_requirement $gig_requirement)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\gig_requirement  $gig_requirement
     * @return \Illuminate\Http\Response
     */
    public function destroy(gig_requirement $gig_requirement)
    {
        //
    }
}

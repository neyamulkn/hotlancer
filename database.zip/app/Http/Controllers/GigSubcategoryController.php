<?php

namespace App\Http\Controllers;

use App\gig_subcategory;
use Illuminate\Http\Request;

class GigSubcategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\gig_subcategory  $gig_subcategory
     * @return \Illuminate\Http\Response
     */
    public function show(gig_subcategory $gig_subcategory)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\gig_subcategory  $gig_subcategory
     * @return \Illuminate\Http\Response
     */
    public function edit(gig_subcategory $gig_subcategory)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\gig_subcategory  $gig_subcategory
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, gig_subcategory $gig_subcategory)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\gig_subcategory  $gig_subcategory
     * @return \Illuminate\Http\Response
     */
    public function destroy(gig_subcategory $gig_subcategory)
    {
        //
    }
}

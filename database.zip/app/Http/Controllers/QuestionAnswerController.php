<?php

namespace App\Http\Controllers;

use App\question_answer;
use Illuminate\Http\Request;

class QuestionAnswerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\question_answer  $question_answer
     * @return \Illuminate\Http\Response
     */
    public function show(question_answer $question_answer)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\question_answer  $question_answer
     * @return \Illuminate\Http\Response
     */
    public function edit(question_answer $question_answer)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\question_answer  $question_answer
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, question_answer $question_answer)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\question_answer  $question_answer
     * @return \Illuminate\Http\Response
     */
    public function destroy(question_answer $question_answer)
    {
        //
    }
}

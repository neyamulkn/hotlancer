<?php

namespace App\Http\Controllers;

use App\gig_image;
use Illuminate\Http\Request;

class GigImageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\gig_image  $gig_image
     * @return \Illuminate\Http\Response
     */
    public function show(gig_image $gig_image)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\gig_image  $gig_image
     * @return \Illuminate\Http\Response
     */
    public function edit(gig_image $gig_image)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\gig_image  $gig_image
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, gig_image $gig_image)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\gig_image  $gig_image
     * @return \Illuminate\Http\Response
     */
    public function destroy(gig_image $gig_image)
    {
        //
    }
}

<?php

namespace App\Http\Controllers;

use App\gig_pirce;
use Illuminate\Http\Request;

class GigPirceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\gig_pirce  $gig_pirce
     * @return \Illuminate\Http\Response
     */
    public function show(gig_pirce $gig_pirce)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\gig_pirce  $gig_pirce
     * @return \Illuminate\Http\Response
     */
    public function edit(gig_pirce $gig_pirce)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\gig_pirce  $gig_pirce
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, gig_pirce $gig_pirce)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\gig_pirce  $gig_pirce
     * @return \Illuminate\Http\Response
     */
    public function destroy(gig_pirce $gig_pirce)
    {
        //
    }
}

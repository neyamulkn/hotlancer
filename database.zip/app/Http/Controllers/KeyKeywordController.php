<?php

namespace App\Http\Controllers;

use App\key_keyword;
use Illuminate\Http\Request;

class KeyKeywordController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\key_keyword  $key_keyword
     * @return \Illuminate\Http\Response
     */
    public function show(key_keyword $key_keyword)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\key_keyword  $key_keyword
     * @return \Illuminate\Http\Response
     */
    public function edit(key_keyword $key_keyword)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\key_keyword  $key_keyword
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, key_keyword $key_keyword)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\key_keyword  $key_keyword
     * @return \Illuminate\Http\Response
     */
    public function destroy(key_keyword $key_keyword)
    {
        //
    }
}

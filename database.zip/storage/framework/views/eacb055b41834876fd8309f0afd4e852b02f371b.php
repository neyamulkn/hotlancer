<?php $__env->startSection('title', 'Hotlancer'); ?>

<?php $__env->startSection('css'); ?>
	<link rel="stylesheet" href="<?php echo e(asset('allscript/css/vendor/simple-line-icons.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('allscript/css/vendor/tooltipster.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('allscript')); ?>/css/vendor/font-awesome.min.css">

	<link rel="stylesheet" href="<?php echo e(asset('allscript')); ?>/css/pricing-table.css">
<style type="text/css">
	
	h3.gigs1 {
    text-align: left;
    padding-bottom: 19px;
	line-height: 34px;
}
.gigs {
    background-color: white;
    padding: 20px;
    padding-bottom: 20px;
}
a.gigs-cat {
    color: black;
}
.post .post-content {
    padding: 10px 16px 20px !important;
    overflow: hidden;
	background-color: white;
}
h3.panel-title.price {
    top: 10px;
}
.accordion.item-faq {
    width: 872px;
    margin: 36px auto 46px;
    background-color: white;
}
h4.gigsfuq-item {
	background: #ffffff;
    border-bottom: 1px solid #ddd;
    padding: 18px;
}
.information-layout .information-layout-item {
    padding: 5px 0 0 0;
    border-bottom: 1px solid #ebebeb;
    overflow: hidden;
}

</style>
<?php $__env->stopSection(); ?>

	<!-- SECTION -->
<?php $__env->startSection('content'); ?>
	<!-- SECTION -->
	<div class="section-wrap">
		<div class="section">
			<!-- SIDEBAR -->
			<div class="sidebar right">
				<div class="sidebar-item author-bio author-badges-v2 column">
					<!-- USER AVATAR -->
					<a href="user-profile.html" class="user-avatar-wrap medium">
						<figure class="user-avatar medium">
							<img src="<?php echo e(asset('allscript')); ?>/images/avatars/avatar_12.jpg" alt="">
						</figure>
					</a>
					<!-- /USER AVATAR -->
					<p class="text-header"><?php echo e($get_user_info->name); ?></p>
					<p class="text-oneline"><?php echo e($get_user_info->userinfo->user_title); ?></p>
					<!-- BADGE LIST -->
					<div class="badge-list short">
						<!-- BADGE LIST ITEM -->
						<div class="badge-list-item">
							<figure class="badge small liquid">
								<img src="<?php echo e(asset('allscript')); ?>/images/badges/community/bronze_s.png" alt="">
							</figure>
						</div>
						<!-- /BADGE LIST ITEM -->

						<!-- BADGE LIST ITEM -->
						<div class="badge-list-item">
							<figure class="badge small liquid">
								<img src="<?php echo e(asset('allscript')); ?>/images/badges/flags/flag_usa_s.png" alt="">
							</figure>
						</div>
						<!-- /BADGE LIST ITEM -->

						<!-- BADGE LIST ITEM -->
						<div class="badge-list-item">
							<figure class="badge small liquid">
								<img src="<?php echo e(asset('allscript')); ?>/images/badges/community/support_s.png" alt="">
							</figure>
						</div>
						<!-- /BADGE LIST ITEM -->

					</div>	
					<!-- /BADGE LIST -->

					<div class="clearfix"></div>
					<a href="<?php echo e(url('/dashbord/inbox/'.$get_user_info->username)); ?>" class="button mid dark-light spaced">Contace me</a>
					<div class="information-layout">
						<!-- INFORMATION LAYOUT ITEM -->
						<div class="information-layout-item">
							<p class="text-header"><span class="icon-energy"></span> From</p>
							<p><b><?php echo e($get_user_info->country); ?></b></p>
						</div>
						<div class="information-layout-item">
							<p class="text-header"><span class="icon-user"></span> Member since</p>
							<p><b><?php echo e(\Carbon\Carbon::parse($get_user_info->created_at)->format('F d, Y')); ?></b></p>
						</div>
						<div class="information-layout-item">
							<p class="text-header"><span class="icon-energy"></span> Avg. Response Time</p>
							<p><b>3 hours</b></p>
						</div>
						<div class="information-layout-item">
							<p class="text-header"><span class="icon-energy"></span> Recent Delivery</p>
							<p><b>15 days</b></p>
						</div>
						<p><?php echo e($get_user_info->userinfo->user_description); ?></p>
						<!-- /INFORMATION LAYOUT ITEM -->
					</div>
					
					
					
					<div class="clearfix"></div>
					
					
				</div>
				<!-- SIDEBAR ITEM -->
				<div class="sidebar-item product-info">
					<h4>Gig Information</h4>
					<hr class="line-separator">
					<!-- INFORMATION LAYOUT -->
					<div class="information-layout">
						<!-- INFORMATION LAYOUT ITEM -->
						<div class="information-layout-item">
							<p class="text-header">Sales:</p>
							<p>22</p>
						</div>
						<!-- /INFORMATION LAYOUT ITEM -->

						<!-- INFORMATION LAYOUT ITEM -->
						<div class="information-layout-item">
							<p class="text-header">Upload Date:</p>
							<p>August 18th, 2015</p>
						</div>
						<!-- /INFORMATION LAYOUT ITEM -->

						<!-- INFORMATION LAYOUT ITEM -->
						<div class="information-layout-item">
							<p class="text-header">Files Included:</p>
							<p>PSD, AI<br>JPEG, PNG</p>
						</div>
						<!-- /INFORMATION LAYOUT ITEM -->

						<!-- INFORMATION LAYOUT ITEM -->
						<div class="information-layout-item">
							<p class="text-header">Requirements:</p>
							<p>CS6 or Lower</p>
						</div>
						<!-- /INFORMATION LAYOUT ITEM -->

						<!-- INFORMATION LAYOUT ITEM -->
						<div class="information-layout-item">
							<p class="text-header">Dimensions:</p>
							<p>4500x2800 Px</p>
						</div>
						<!-- /INFORMATION LAYOUT ITEM -->

						<!-- INFORMATION LAYOUT ITEM -->
						<div class="information-layout-item">
							<p class="tags primary">
								<?php $gig_search_tag = explode(',', $get_gig_info->gig_search_tag); ?>

								<?php $__currentLoopData = $gig_search_tag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $search_tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<a href="#"><?php echo e($search_tag); ?></a>,
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</p>
						</div>
						<!-- /INFORMATION LAYOUT ITEM -->
					</div>
					<!-- INFORMATION LAYOUT -->
				</div>
				<!-- /SIDEBAR ITEM -->
				
			</div>
			
			
			<!-- /SIDEBAR -->

			<!-- CONTENT -->
			<div class="content left">
				<!-- POST -->
				<div class="gigs">
					<h3 class="gigs1">I will <?php echo e($get_gig_info->gig_title); ?></h3>
					<hr class="line-separator"><br>
					<a class="gigs-cat" href="#">Gigs / Graphics & Design / Web & Mobile Design</a>
				</div>
				<article class="post">
					<!-- POST IMAGE -->
					<div class="post-image">
						<figure class="product-preview-image large liquid">
							<img src="<?php echo e(asset('/gigimages/'.$get_gig_info->get_image->image_path)); ?>" alt="">
						</figure>
						<!-- SLIDE CONTROLS -->
						<div class="slide-control-wrap">
							<div class="slide-control rounded left">
								<!-- SVG ARROW -->
								<svg class="svg-arrow">
									<use xlink:href="#svg-arrow"></use>
								</svg>
								<!-- /SVG ARROW -->
							</div>

							<div class="slide-control rounded right">
								<!-- SVG ARROW -->
								<svg class="svg-arrow">
									<use xlink:href="#svg-arrow"></use>
								</svg>
								<!-- /SVG ARROW -->
							</div>
						</div>
						<!-- /SLIDE CONTROLS -->
						
					</div>
					<!-- /POST IMAGE -->

					<!-- POST IMAGE SLIDES -->
					<div class="post-image-slides">
						<!-- IMAGE SLIDES WRAP -->
						<div class="image-slides-wrap full">
							<!-- IMAGE SLIDES -->
							<div class="image-slides" data-slide-visible-full="8" data-slide-visible-small="2" data-slide-count="9">
								<!-- IMAGE SLIDE -->
								<?php $__currentLoopData = $get_gig_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gig_image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="image-slide ">
									<div class="overlay"></div>
									<figure class="product-preview-image thumbnail liquid">
										<img src="<?php echo e(asset('gigimages/'.$gig_image->image_path)); ?>" alt="">
									</figure>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<!-- /IMAGE SLIDE -->

							</div>
							<!-- IMAGE SLIDES -->
						</div>
						<!-- IMAGE SLIDES WRAP -->
					</div>
					<!-- /POST IMAGE SLIDES -->
				</article>
				<table class="table table-hover table-bordered" style="margin-bottom: 20px; text-align:center;padding-left:200px; padding-right:200px; background-color: white;">
					<thead>
					  <tr>
						  <th><center></center></th>
						  <th><center><h3>Basic</h3></center></th>
						  <th><center><h3>Plus</h3></center></th>
						  <th><center><h3>Super</h3></center></th>
						  <th><center><h3>Platinum</h3></center></th>
					  </tr>
					</thead>
					<tbody>
					  <tr>
						<td><br>Price</td>
						<td><h3 class="panel-title price">$<?php echo e($get_gig_price->basic_p); ?></h3></td>
						<td><h3 class="panel-title price">$<?php echo e($get_gig_price->plus_p); ?></h3></td>
						<td><h3 class="panel-title price">$<?php echo e($get_gig_price->super_p); ?></h3></td>
						<td><h3 class="panel-title price">$<?php echo e($get_gig_price->platinum_p); ?></h3></td>
					  </tr>
					  <tr>
						<td><b>Packages</b></td>
						<td><?php echo e($get_gig_price->basic_title); ?></td>
						<td><?php echo e($get_gig_price->plus_title); ?></td>
						<td><?php echo e($get_gig_price->super_title); ?></td>
						<td><?php echo e($get_gig_price->platinum_title); ?></td>
					  </tr>
					  <tr>
						<td>Description</td>
						<td><?php echo e($get_gig_price->basic_dsc); ?></td>
						<td><?php echo e($get_gig_price->plus_dsc); ?></td>
						<td><?php echo e($get_gig_price->super_dsc); ?></td>
						<td><?php echo e($get_gig_price->platinum_dsc); ?></td>
					  </tr>
					  <tr>
						<td>Revisions</td>
						<td><?php echo e($get_gig_price->rivision_b); ?></td>
						<td><?php echo e($get_gig_price->rivision_p); ?></td>
						<td><?php echo e($get_gig_price->rivision_s); ?></td>
						<td><?php echo e($get_gig_price->rivision_pm); ?></td>
					  </tr>

					  <?php $__currentLoopData = $get_gig_feature; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gig_feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					  <tr>
						<td><?php echo e($gig_feature->feature_name); ?></td>
						<td><?php if($gig_feature->feature_basic == 'Yes') {echo '<i style="color:#1fd0b6;font-size: 15px;" class="fa fa-check fa-lg"></i>'; }else{ echo '<i style="color:black;font-size: 15px;" class="fa fa-minus fa-lg"></i>';} ?></td>
						<td><?php if($gig_feature->feature_plus == 'Yes') {echo '<i style="color:#1fd0b6;font-size: 15px;" class="fa fa-check fa-lg"></i>'; }else{ echo '<i style="color:black;font-size: 15px;" class="fa fa-minus fa-lg"></i>';} ?></td>
						<td><?php if($gig_feature->feature_super == 'Yes') {echo '<i style="color:#1fd0b6;font-size: 15px;" class="fa fa-check fa-lg"></i>'; }else{ echo '<i style="color:black;font-size: 15px;" class="fa fa-minus fa-lg"></i>';} ?></td>
						<td><?php if($gig_feature->feature_platinum == 'Yes') {echo '<i style="color:#1fd0b6;font-size: 15px;" class="fa fa-check fa-lg"></i>'; }else{ echo '<i style="color:black;font-size: 15px;" class="fa fa-minus fa-lg"></i>';} ?></td>
					  </tr>
					 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					 
					 	<tr>
						<td>Daily Work</td>
						<td> 1 hour</td>
						<td> 3 hour</td>
						<td> 4 hour</td>
						<td> 6 hour</td>
					  </tr>
					  <tr>
						<td>Delivery time</td>
						<td><?php echo e($get_gig_price->delivery_time_b); ?> days</td>
						<td><?php echo e($get_gig_price->delivery_time_p); ?> days</td>
						<td><?php echo e($get_gig_price->delivery_time_s); ?> days</td>
						<td><?php echo e($get_gig_price->delivery_time_pm); ?> days</td>
					  </tr>
					  <tr>
						</tr><tr><td></td>
						<td><a class="btn btn-info" style="margin-top:10px; margin-bottom:10px">Order Now</a></td>
						<td><a class="btn btn-info" style="margin-top:10px; margin-bottom:10px">Order Now</a></td>
						<td><a class="btn btn-info" style="margin-top:10px; margin-bottom:10px">Order Now</a></td>
						<td><a class="btn btn-info" style="margin-top:10px; margin-bottom:10px">Order Now</a></td></tr>
					</tbody>
				  </table>
				
				<article class="post">
					<!-- POST CONTENT -->
					<div class="post-content">
						<!-- POST PARAGRAPH -->
						<div class="post-paragraph">
							<p><?php echo e($get_gig_info->gig_dsc); ?></p>
						</div>
						<!-- /POST PARAGRAPH -->

						<div class="clearfix"></div>
					</div>
					<!-- /POST CONTENT -->

					<hr class="line-separator">

					<!-- SHARE -->
					<div class="share-links-wrap">
						<p class="text-header small">Share this:</p>
						<!-- SHARE LINKS -->
						<ul class="share-links hoverable">
							<li><a href="#" class="fb"></a></li>
							<li><a href="#" class="twt"></a></li>
							<li><a href="#" class="db"></a></li>
							<li><a href="#" class="rss"></a></li>
							<li><a href="#" class="gplus"></a></li>
						</ul>
						<!-- /SHARE LINKS -->
					</div>
					<!-- /SHARE -->
				</article>
				<!-- /POST -->
				<div class="accordion item-faq primary">
					<!-- ACCORDION ITEM -->
					<h4 class="gigsfuq-item">Frequently Asked Questions</h4>

					<?php $__currentLoopData = $get_question_answer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question_answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="accordion-item">
						<h6 class="accordion-item-header"><?php echo e($question_answer->question); ?></h6>
						<!-- SVG ARROW -->
						<svg class="svg-arrow">
							<use xlink:href="#svg-arrow"></use>
						</svg>
						<!-- /SVG ARROW -->
						<div class="accordion-item-content">
							<p><?php echo e($question_answer->answer); ?></p>
						</div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<!-- /ACCORDION ITEM -->

				
					
				</div>
				<div class="comment-list">
				<h4 class="gigsfuq-item">Reviews (1175)</h4>
				
					<!-- COMMENT -->
					<div class="comment-wrap">
						<!-- USER AVATAR -->
						<a href="user-profile.html">
							<figure class="user-avatar medium">
								<img src="<?php echo e(asset('allscript')); ?>/images/avatars/avatar_11.jpg" alt="">
							</figure>
						</a>
						<!-- /USER AVATAR -->
						<div class="comment">
							<p class="text-header">View as Author (Reply Option)</p>
							<p class="timestamp">8 Hours Ago</p>
							<a href="#" class="report">Report</a>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magnada. Ut enim ad minim veniam, quis nostrud exercitation.</p>
						</div>
					</div>
					<!-- /COMMENT -->

					<!-- LINE SEPARATOR -->
					<hr class="line-separator">
					<!-- /LINE SEPARATOR -->

					<!-- COMMENT -->
					<div class="comment-wrap">
						<!-- USER AVATAR -->
						<a href="user-profile.html">
							<figure class="user-avatar medium">
								<img src="<?php echo e(asset('allscript')); ?>/images/avatars/avatar_12.jpg" alt="">
							</figure>
						</a>
						<!-- /USER AVATAR -->
						<div class="comment">
							<p class="text-header">View as Author (Replies)</p>
							<p class="timestamp">10 Hours Ago</p>
							<a href="#" class="report">Report</a>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magnada. Ut enim ad minim veniam, quis nostrud exercitation.</p>
						</div>

						<!-- COMMENT -->
						<div class="comment-wrap">
							<!-- USER AVATAR -->
							<a href="user-profile.html">
								<figure class="user-avatar medium">
									<img src="<?php echo e(asset('allscript')); ?>/images/avatars/avatar_09.jpg" alt="">
								</figure>
							</a>
							<!-- /USER AVATAR -->
							<div class="comment">
								<p class="text-header">Odin_Design</p>
								<!-- PIN -->
								<span class="pin">Author</span>
								<!-- /PIN -->
								<p class="timestamp">2 Hours Ago</p>
								<a href="#" class="report">Report</a>
								<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magnada. Ut enim ad minim veniam, quis nostrud exercitation</p>
							</div>
						</div>
						<!-- /COMMENT -->
					</div>
				</div>
				<div class="clearfix"></div><br>
				<div class="product-list grid column4-wrap">
					<!-- PRODUCT ITEM -->
					<?php
						$get_another_gig = DB::table('gig_basics')->where('gig_user_id', $get_user_info->id)->where('gig_status', 'active')->get(); 

						if(count($get_another_gig)>1){
					?>

					<?php $__currentLoopData = $get_another_gig; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $another_gig): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="product-item column">
						<!-- PRODUCT PREVIEW ACTIONS -->
						<div class="product-preview-actions">
							<!-- PRODUCT PREVIEW IMAGE -->
							<figure class="product-preview-image">
							<?php
								$get_image = DB::table('gig_images')->where('gig_id', $another_gig->gig_id)->first(); ?>
								
								<img src="<?php echo e(asset('/gigimages/'.$get_image->image_path)); ?>" alt="product-image">
							
							</figure>
							<!-- /PRODUCT PREVIEW IMAGE -->

							<!-- PREVIEW ACTIONS -->
							<div class="preview-actions">
								<!-- PREVIEW ACTION -->
								<div class="preview-action">
									<a href="<?php echo e(url($get_user_info->username.'/'.$another_gig->gig_url)); ?>" target="_blank">
										<div class="circle tiny primary">
											<span class="icon-tag"></span>
										</div>
									</a>
									<a href="<?php echo e(url($get_user_info->username.'/'.$another_gig->gig_url)); ?>" target="_blank">
										<p>Go to Item </p>
									</a>
								</div>
								<!-- /PREVIEW ACTION -->

								<!-- PREVIEW ACTION -->
								<div class="preview-action">
									<a href="#">
										<div class="circle tiny secondary">
											<span class="icon-heart"></span>
										</div>
									</a>
									<a href="#">
										<p>Favourites +</p>
									</a>
								</div>
								<!-- /PREVIEW ACTION -->
							</div>
							<!-- /PREVIEW ACTIONS -->
						</div>
						<!-- /PRODUCT PREVIEW ACTIONS -->

						<!-- PRODUCT INFO -->
						<div class="product-info">
							<a href="<?php echo e(url($get_user_info->username.'/'.$another_gig->gig_url)); ?>" target="_blank"">
								<p class="text-header">I will <?php echo e($another_gig->gig_title); ?></p>
							</a>
							<a href="shop-gridview-v1.html">
								<p class="category primary">PSD Templates</p>
							</a>
							<p class="price"><span>$</span><?php $get_gig_price = DB::table('gig_prices')->select('basic_p')->where('gig_id', $another_gig->gig_id)->first(); 
									if($get_gig_price){ 
										echo $get_gig_price->basic_p;
										}
									?></p>
						</div>
						<!-- /PRODUCT INFO -->
						<hr class="line-separator">

						<!-- USER RATING -->
						<div class="user-rating">
							<a href="author-profile.html">
								<figure class="user-avatar small">
									<img src="<?php echo e(asset('allscript')); ?>/images/avatars/avatar_01.jpg" alt="user-avatar">
								</figure>
							</a>
							<a href="<?php echo e(url($get_user_info->username)); ?>">
								<p class="text-header tiny"><?php echo e($get_user_info->name); ?></p>
							</a>
							<ul class="rating tooltip tooltipstered">
								<li class="rating-item">
									<!-- SVG STAR -->
									<svg class="svg-star">
										<use xlink:href="#svg-star"></use>
									</svg>
									<!-- /SVG STAR -->
								</li>
								<li class="rating-item">
									<!-- SVG STAR -->
									<svg class="svg-star">
										<use xlink:href="#svg-star"></use>
									</svg>
									<!-- /SVG STAR -->
								</li>
								<li class="rating-item">
									<!-- SVG STAR -->
									<svg class="svg-star">
										<use xlink:href="#svg-star"></use>
									</svg>
									<!-- /SVG STAR -->
								</li>
								<li class="rating-item">
									<!-- SVG STAR -->
									<svg class="svg-star">
										<use xlink:href="#svg-star"></use>
									</svg>
									<!-- /SVG STAR -->
								</li>
								<li class="rating-item empty">
									<!-- SVG STAR -->
									<svg class="svg-star">
										<use xlink:href="#svg-star"></use>
									</svg>
									<!-- /SVG STAR -->
								</li>
							</ul>
						</div>
						<!-- /USER RATING -->
					</div>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<!-- /PRODUCT ITEM -->
				<?php } ?>
				</div>
			</div>
			
			<!-- CONTENT -->
		</div>
		
	</div>
<!-- /SECTION -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<!-- Tooltipster -->
<script src="<?php echo e(asset('/allscript')); ?>/js/vendor/jquery.tooltipster.min.js"></script>
<!-- ImgLiquid -->
<script src="<?php echo e(asset('/allscript')); ?>/js/vendor/imgLiquid-min.js"></script>
<!-- XM Tab -->
<script src="<?php echo e(asset('/allscript')); ?>/js/vendor/jquery.xmtab.min.js"></script>
<!-- Tweet -->
<script src="<?php echo e(asset('/allscript')); ?>/js/vendor/twitter/jquery.tweet.min.js"></script>
<!-- Side Menu -->
<script src="<?php echo e(asset('/allscript')); ?>/js/side-menu.js"></script>
<!-- Liquid -->
<script src="<?php echo e(asset('/allscript')); ?>/js/liquid.js"></script>
<!-- Checkbox Link -->
<script src="<?php echo e(asset('/allscript')); ?>/js/checkbox-link.js"></script>
<!-- Image Slides -->
<script src="<?php echo e(asset('/allscript')); ?>/js/image-slides.js"></script>
<!-- Post Tab -->
<script src="<?php echo e(asset('/allscript')); ?>/js/post-tab.js"></script>
<!-- XM Accordion -->
<script src="<?php echo e(asset('/allscript')); ?>/js/vendor/jquery.xmaccordion.min.js"></script>
<!-- XM Pie Chart -->
<script src="<?php echo e(asset('/allscript')); ?>/js/vendor/jquery.xmpiechart.min.js"></script>
<!-- Item V1 -->
<script src="<?php echo e(asset('/allscript')); ?>/js/item-v1.js"></script>
<!-- Tooltip -->
<script src="<?php echo e(asset('/allscript')); ?>/js/tooltip.js"></script>
<!-- User Quickview Dropdown -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
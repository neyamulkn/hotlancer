<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0">
	<link rel="stylesheet" href="<?php echo e(asset('allscript/css/vendor/simple-line-icons.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('allscript/css/vendor/tooltipster.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('allscript/css/vendor/owl.carousel.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('allscript/css/style.css')); ?>">
	<!-- favicon -->
	<link rel="icon" href="favicon.ico">
	<title><?php echo $__env->yieldContent('title'); ?></title>
	<?php echo $__env->yieldContent('css'); ?>
</head>
<body>

	<!-- HEADER -->
	<div class="header-wrap">
		<header>
			<!-- LOGO -->
			<a href="">
				<figure class="logo">
					<img src="<?php echo e(asset('allscript/images/logo.png')); ?>" alt="logo">
				</figure>
			</a>
			<!-- /LOGO -->

			<!-- MOBILE MENU HANDLER -->
			<div class="mobile-menu-handler left primary">
				<img src="<?php echo e(asset('allscript/images/pull-icon.png')); ?>" alt="pull-icon">
			</div>
			<!-- /MOBILE MENU HANDLER -->

			<!-- LOGO MOBILE -->
			<a href="">
				<figure class="logo-mobile">
					<img src="<?php echo e(asset('allscript/images/logo_mobile.png')); ?>" alt="logo-mobile">
				</figure>
			</a>
			<!-- /LOGO MOBILE -->

			<!-- MOBILE ACCOUNT OPTIONS HANDLER -->
			<div class="mobile-account-options-handler right secondary">
				<img src="<?php echo e(asset('allscript/images/pull-icon.png')); ?>" alt="pull-icon">
			</div>
			<!-- /MOBILE ACCOUNT OPTIONS HANDLER -->

			<div class="menu-bar-search">
				<form class="search-form">
					<input type="text" class="rounded" name="search" id="search_products" placeholder="Search products here...">
					<input type="image" src="<?php echo e(asset('allscript/images/search-icon.png')); ?>" alt="search-icon">
				</form>
			</div>
			
			<!-- USER BOARD -->
			<div class="user-board">
				<!-- ACCOUNT ACTIONS -->
				<div class="account-actions no-space">
					<a href="" class="interesting-link header-link-login">Find Jobs</a>
					<a href="" class="interesting-link header-link-login">Find Gigs</a>
					<a href="" class="interesting-link header-link-login">Find Themes</a>
					<a href="" class="interesting-link header-link-login">Register</a>
					<a href="" class="interesting-link header-link-login">Login</a>
					<a href="" class="interesting-link header-link-login post-a-job-button">Post a Job</a>
				</div>
				<!-- /ACCOUNT ACTIONS -->
			</div>
			<!-- /USER BOARD -->
		</header>
	</div>
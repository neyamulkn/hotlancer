<?php $__env->startSection('css'); ?>
	<link rel="stylesheet" href="<?php echo e(asset('/allscript')); ?>/css/icon.css">
	<link rel="stylesheet" href="<?php echo e(asset('/allscript')); ?>/css/login.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <!-- DASHBOARD CONTENT -->
        <div class="dashboard-content">
            <!-- HEADLINE -->
            <div class="headline buttons primary">
                <h4 style="color: red">404 Not Found!.</h4>
				
            </div>
            <!-- /HEADLINE -->
         
        </div>
        <!-- DASHBOARD CONTENT -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
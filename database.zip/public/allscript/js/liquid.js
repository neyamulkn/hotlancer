(function($) {
	$('.liquid').imgLiquid();
})(jQuery);
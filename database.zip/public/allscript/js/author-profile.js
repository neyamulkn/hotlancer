(function($){
	$('.pie-chart1').xmpiechart({
		width: 176,
		height: 176,
		percent: 86,
		fillWidth: 8,
		gradient: true,
		gradientColors: ['#10fac0', '#1cbdf9'],
		speed: 2,
		outline: true,
		linkPercent: '.percent'
	});
})(jQuery);

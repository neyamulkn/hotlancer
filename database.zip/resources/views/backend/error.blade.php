@extends('backend.layouts.master')


@section('css')
	<link rel="stylesheet" href="{{asset('/allscript')}}/css/icon.css">
	<link rel="stylesheet" href="{{asset('/allscript')}}/css/login.css">
@endsection

@section('content')
        <!-- DASHBOARD CONTENT -->
        <div class="dashboard-content">
            <!-- HEADLINE -->
            <div class="headline buttons primary">
                <h4 style="color: red">404 Not Found!.</h4>
				
            </div>
            <!-- /HEADLINE -->
         
        </div>
        <!-- DASHBOARD CONTENT -->

@endsection
